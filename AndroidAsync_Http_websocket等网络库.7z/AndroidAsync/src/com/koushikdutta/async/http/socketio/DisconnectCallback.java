package com.koushikdutta.async.http.socketio;

/**
 * Created by koush on 7/2/13.
 */
public interface DisconnectCallback {
    void onDisconnect(Exception e);
}
