package com.koushikdutta.async.http.server;

public class StreamSkipException extends Exception {
    public StreamSkipException(String message) {
        super(message);
    }
}
