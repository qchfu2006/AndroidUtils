package com.koushikdutta.async;

public interface AsyncServerSocket {
    public void stop();
    public int getLocalPort();
}
