package com.koushikdutta.async;


public interface TapCallback {
}
